const CLIENT_ID = "tfuo8d6oz56i1ljpdoeoboj0ccf04tak";
const CLIENT_SECRET = "a6xuRXxblm42vk5aeHewuYrzr5UZ80qv";
const REDIRECT_URL = "https://test7.jeeni.in/scalar";

const BASE_URL = "https://test7.jeeni.in";

export { CLIENT_ID, CLIENT_SECRET, REDIRECT_URL, BASE_URL };
