import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./features/authSlice";

import auditFolderSlice from "./features/auditfolder/auditFolderSlice";

const store = configureStore({
  reducer: {
    auth: authReducer,
    folder: auditFolderSlice,
  },
});

// export const TOKEN =
//   "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJwb29qYXBAa2FuemVuY3MuY29tIiwiaWF0IjoxNzA4NTA0MjIwLCJleHAiOjE3MDg1MTE0MjB9.FAW2S1dy6pv6xqt33xty49rFjKIAIx0w0LH8AKUVWkE";

export default store;
