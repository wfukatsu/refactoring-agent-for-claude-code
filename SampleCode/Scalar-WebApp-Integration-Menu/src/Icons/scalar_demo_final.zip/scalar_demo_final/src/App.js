import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import ViewEventHistory from "./components/ViewEventHistory";
import FolderAuditorDashboard from "./features/auditfolder/FolderAuditorDashboard";

function App() {
  const root = {
    children: [
      { name: "empty_folder", itemType: "folder", children: [] },
      {
        name: "public",
        itemType: "folder",
        children: [
          { name: "index.html", itemType: "file" },
          { name: "fav.html", itemType: "file" },
        ],
      },
      {
        name: "src",
        itemType: "folder",
        children: [
          { name: "App.css", itemType: "file" },
          { name: "App.js", itemType: "file" },
          {
            name: "components",
            itemType: "folder",
            children: [
              { name: "A.js", itemType: "file" },
              { name: "B.js", itemType: "file" },
            ],
          },
        ],
      },
    ],
  };

  return (
    <BrowserRouter>
      <Routes>
        {/* <Route
          path="/scalar"
          element={<FolderAuditorDashboard items={root} />}
        /> */}
        <Route path="/scalar" element={<Dashboard />} />
        <Route path="/event-history" element={<ViewEventHistory />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
