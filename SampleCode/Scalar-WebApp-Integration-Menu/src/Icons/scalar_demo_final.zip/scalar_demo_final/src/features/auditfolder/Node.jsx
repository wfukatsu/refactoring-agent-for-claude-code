import "./Root.css";
import { ReactComponent as FolderIcon } from "../../assets/folder_icon.svg";
import { ReactComponent as FileIcon } from "../../assets/file-icon.svg";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export default function Node({ item, isRootAllowed, isRoot }) {
  const { user } = useSelector((store) => store.auth);
  const [itemDetails, setItemdetails] = useState(false);
  const dispatch = useDispatch();
  const { deniedList } = useSelector((store) => store.folder);

  const isDenied = [...deniedList].filter((o) => o.itemId === item.id).length;

  async function fetchItem() {
    if (item.type === "file") {
      return;
    }
    let baseUrl = "http://test7.jeeni.in";
    console.log("before fetchItem");
    if (!itemDetails) {
      console.log("fetchItem", item.id, user.jwtToken);
      const headers = new Headers();
      headers.append("Content-Type", "application/json");
      headers.append(
        "Authorization",
        `Bearer ${encodeURIComponent(user.jwtToken)}`
      );

      const url = `${baseUrl}/box/folder/getItemList?folderId=${encodeURIComponent(
        item.id
      )}`;
      const response = await fetch(url, {
        method: "GET",
        headers: headers,
      });

      if (response.ok) {
        const jsonData = await response.json();
        console.log(jsonData.data);
        setItemdetails([...jsonData.data]);
      }
      // setItemdetails("ss");
    }
  }

  return (
    <>
      <div className="node-item">
        {item.type === "folder" ? (
          <FolderIcon className="folder" />
        ) : (
          <FileIcon className="folder" />
        )}
        <details open={false} onClick={fetchItem}>
          <summary>
            {!isRoot && (
              <button
                style={{
                  width: "30px",
                  height: "40px",
                  fontSize: "20px",
                  fontWeight: "bold",
                }}
                onClick={() => {
                  console.log("updateDeniedList");
                  dispatch({
                    type: "auditFolder/toggleDenaiList",
                    payload: {
                      id: item.id,
                      itemType: item.type,
                    },
                  });
                }}
              >
                {isDenied ? <>&times;</> : <>&#x2713;</>}
              </button>
            )}

            {item.name}
          </summary>

          {itemDetails && (
            <div className="align-right">
              <ul>
                {itemDetails.map((item, index) => {
                  return (
                    <li key={index}>
                      <Node
                        item={item}
                        isRootAllowed={!isDenied}
                        isRoot={false}
                      />
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </details>
      </div>
    </>
  );
}
