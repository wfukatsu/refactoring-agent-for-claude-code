import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  auditSetList: [],
  selectedAuditSet: "null",
  deniedList: [],
  orgDeniedList: [],
};

const folderSlice = createSlice({
  name: "auditFolder",
  initialState,
  reducers: {
    updateAuditSet(state, action) {
      state.auditSetList = action.payload.auditSetList;
    },
    updateSelectedAuditSet(state, action) {
      // state.selectedAuditSet = action.payload.auditSet;
      // state = {
      //   ...state,
      //   selectedAuditSet: action.payload.auditSet,
      //   deniedList: [...action.payload.deniedList],
      //   orgDeniedList: [...action.payload.deniedList],
      // };
      state.selectedAuditSet = action.payload.auditSet;
      state.deniedList = [...action.payload.deniedList];
      state.orgDeniedList = [...action.payload.deniedList];
      // console.log("updateAuditSet STATE", action.payload.auditSet);
      console.log("updateAuditSet LIST", state.deniedList);
      console.log("updateAuditSet ORG", state.orgDeniedList);
    },
    toggleDenaiList(state, action) {
      let itemId = action.payload.id;
      let itemType = action.payload.itemType;
      if (state.deniedList.find((obj) => obj.itemId === itemId)) {
        state.deniedList = state.deniedList.filter(
          (item) => item.itemId !== itemId
        );
        console.log("IF SLICE", state.deniedList);
      } else {
        state.deniedList = [{ itemId, itemType }, ...state.deniedList];
        console.log("ELSE SLICE", state.deniedList);
      }
    },
    updateDenaiList(state, action) {
      state.deniedList = [...action.payload.deniedList];
      state.orgDeniedList = [...action.payload.deniedList];
      console.log("updateDenaiList STATE", state.selectedAuditSet);
      console.log("updateDenaiList LIST", state.deniedList);
    },
  },
});

export const { updateAuditSet, updateSelectedAuditSet } = folderSlice.actions;

export default folderSlice.reducer;
