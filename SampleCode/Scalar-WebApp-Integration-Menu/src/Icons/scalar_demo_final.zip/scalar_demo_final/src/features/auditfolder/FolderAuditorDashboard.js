import { Popover } from "@mui/material";
import DropDown from "../../components/DropDown";
import Node from "./Node";
import { useDispatch, useSelector } from "react-redux";
import { useState } from "react";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import Header from "../../components/Header";
import FileDetails from "../../components/FileDetails";
function compareLists(list1, list2) {
  if (list1.length !== list2.length) {
    return false;
  }

  list1.sort((a, b) => a.itemId - b.itemId);
  list2.sort((a, b) => a.itemId - b.itemId);

  for (let i = 0; i < list1.length; i++) {
    if (list1[i].itemId !== list2[i].itemId) {
      return false;
    }
  }

  return true;
}

export default function FolderAuditorDashboard({ itemdata }) {
  const { user } = useSelector((store) => store.auth);
  const [fileDetailsBox, setfileDetailsBox] = useState(true);

  const { itemDetails } = { ...user };

  const [anchorEl, setAnchorEl] = useState(null);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const dispatch = useDispatch();

  const { selectedAuditSet, deniedList, orgDeniedList } = useSelector(
    (store) => store.folder
  );

  const isSame = compareLists([...orgDeniedList], [...deniedList]);

  console.log("ISSAME : ", isSame);
  const hasChange = selectedAuditSet !== "null" && !isSame;
  // const hasChange = true;

  console.log("HASCHANGED :: ", hasChange);
  console.log("ORG ", orgDeniedList);
  console.log("DENIED ", deniedList);
  console.log("selectedAuditSet ", selectedAuditSet);

  // const itemdata = {
  //   id: 240062903338,
  //   name: "NEW FOLDER",
  //   type: "folder",
  //   description: "",
  //   createdAt: "2023/12/15 12:50:10",
  //   modifiedAt: "2024/02/13 10:36:55",
  //   size: 152096,
  //   ownedBy: {
  //     type: "USER",
  //     id: "29490661237",
  //     name: "Pooja Patil",
  //     login: "poojap@kanzencs.com",
  //   },
  //   modifiedBy: {
  //     type: "USER",
  //     id: "29490661237",
  //     name: "Pooja Patil",
  //     login: "poojap@kanzencs.com",
  //   },
  //   path: null,
  // };

  async function addHandler() {
    let baseUrl = "http://test7.jeeni.in";

    let body = {
      itemId: itemdata.id,
      itemType: itemdata.type,
      itemName: itemdata.name,
      accessListType: null,
      denyItems: [...deniedList],
    };
    const headers = new Headers();
    headers.append("Content-Type", "application/json");
    headers.append(
      "Authorization",
      `Bearer ${encodeURIComponent(user.jwtToken)}`
    );
    const url = `${baseUrl}/box/auditSetItem/addItemToAuditSet/${selectedAuditSet}`;
    const response = await fetch(url, {
      method: "POST",
      headers: headers,
      body: JSON.stringify(body),
    });

    if (response.ok) {
      const jsonData = await response.json();
      console.log("RESPONSE", jsonData.data);
      let deniedList = [...jsonData.data];
      console.log("LENGTH :: ", deniedList.length);
      dispatch({
        type: "auditFolder/updateDenaiList",
        payload: { deniedList },
      });
    }
  }

  return (
    <div className="w-full">
      <Header />
      <div className="flex ">
        <h1 className="text-xl text-black bg-white font-bold">
          Folder Name: EY@Mark23-24
        </h1>
        <p className="text-md flex justify-center items-center ">
          File Path:Ms.Doc./
        </p>
      </div>
      <div className="main px-5">
        <div className="bg-[#F9FBFE] border rounded-tr-xl  rounded-br-xl rounded-tl-xl  border-gray-300  rounded-bl-xl w-[80%]">
          <h1>Add to Audit Set</h1>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginRight: "30px",
            }}
          >
            <DropDown itemId={itemdata.id} />
          </div>

          <div
            style={{ backgroundColor: "rgba(0, 0, 0, 0.25)", height: "1px" }}
          ></div>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "10px 20px",
            }}
          >
            <h2
              style={{
                fontSize: "16px",
                fontWeight: "700",
                color: "rgba(0, 0, 0, 1)",
              }}
            >
              Select files and subfolders to be allowed
            </h2>
            <div
              style={{
                fontSize: "16px",
                fontWeight: "bolder",
              }}
            >
              <p>
                Allowed
                <span>
                  {"  "}
                  <>&#x2713;</>
                  {"      "}
                </span>
                Denied
                <span>
                  {"  "}
                  <>&times;</>
                </span>
              </p>
            </div>
          </div>

          {/* <div
            style={{ backgroundColor: "rgba(0, 0, 0, 0.25)", height: "1px" }}
          ></div> */}

          <div className="flex border border-gray-400 min-h-[500px] px-4 py-4">
            <Node item={itemdata} isRootAllowed={true} isRoot={true} />

            {selectedAuditSet === "null" && (
              <Popover
                id="mouse-over-popover"
                sx={{
                  pointerEvents: "none",
                }}
                open={open}
                anchorEl={anchorEl}
                anchorOrigin={{
                  vertical: "bottom",
                  horizontal: "left",
                }}
                transformOrigin={{
                  vertical: "top",
                  horizontal: "left",
                }}
                onClose={handlePopoverClose}
                disableRestoreFocus
              >
                <h1 style={{ padding: "5px 10px" }}>Please select Audit Set</h1>
              </Popover>
            )}
          </div>
          <div className="flex justify-end p-4">
            <button
              onClick={hasChange ? addHandler : null}
              aria-owns={open ? "mouse-over-popover" : undefined}
              onMouseEnter={handlePopoverOpen}
              onMouseLeave={handlePopoverClose}
              className={`bg-[#0061D5] hover:bg-blue-800 text-white font-bold py-2 px-4 rounded-full ${
                hasChange ? "" : "opacity-50 cursor-not-allowed"
              }`}
            >
              Add
            </button>
          </div>
        </div>
        <div className="w-[25%]">
        <FileDetails obj={itemDetails} isfiledetails={false} />
        </div>
        {/* <div
          style={{
            width: "full",
            borderRadius: "16px",
            top: "306px",
            left: "1093px",
          }}
        >
          <div
            style={{
              width: "100%",
              backgroundColor: "#0061D5",
              fontSize: "20px",
              fontWeight: "700",
              borderTopLeftRadius: "16px",
              borderTopRightRadius: "16px",
              minHeight: "59px",
              color: "white",
              paddingLeft: "22px",
              paddingRight: "10px",
              paddingTop: "12px",
              paddingBottom: "12px",
            }}
          >
            Folder Details
          </div>

          <div className="flex w-full px-7 py-2 border border-gray-400 gap-5 justify-start items-center">
            <CalendarTodayIcon sx={{ color: "blue" }} />
            <div className="felx flex-col">
              <p className="text-md">createdAt</p>
              <p className="text-[17px]  font-bold">10/12/2023</p>
            </div>
          </div>

          <div className="flex w-full px-7 py-2 border border-gray-400 gap-5 justify-start items-center">
            <CalendarTodayIcon sx={{ color: "blue" }} />
            <div className="felx flex-col">
              <p className="text-md">createdAt</p>
              <p className="text-[17px]  font-bold">10/12/2023</p>
            </div>
          </div>

          <div className="flex w-full px-7 rounded-bl-xl rounded-br-xl py-2 border border-gray-400 gap-5 justify-start items-center">
            <CalendarTodayIcon sx={{ color: "blue" }} />
            <div className="felx flex-col">
              <p className="text-md">createdAt</p>
              <p className="text-[17px]  font-bold">10/12/2023</p>
            </div>
          </div>

         
        </div> */}
      </div>
    </div>
  );
}
