import { useEffect, useState } from "react";
import SignUp from "../components/SignUp";
import Loader from "../components/Loader";
import { useSearchParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import {
  BASE_URL,
  CLIENT_ID,
  CLIENT_SECRET,
  REDIRECT_URL,
} from "../utils/constant";
import Error from "../components/Error";
import AuditorDashboard from "../components/AuditorDashboard";
import FolderAuditorDashboard from "../features/auditfolder/FolderAuditorDashboard";

const SHOW_DATA = "SHOW_DATA";
const SHOW_LOADING = "SHOW_LOADING";
const SHOW_ERROR = "SHOW_ERROR";
const SHOW_SIGNUP = "SHOW_SIGNUP";

function Dashboard() {
  const [screen, setScreen] = useState({ screen: SHOW_LOADING, data: {} });
  const dispatch = useDispatch();

  const [searchParams, setSearchParams] = useSearchParams();

  const state = searchParams.get("state");
  const code = searchParams.get("code");
  let itemId = searchParams.get("file_id");
  let userId = searchParams.get("user_id");
  const authCode = searchParams.get("auth_code");
  let redirectUrl = searchParams.get("redirect_url");

  // itemId = 1443204769634;
  // userId = 29490661237;

  // redirectUrl =
  //   "https://app.box.com/index.php?rm=box_openbox_redirect_to_box&service_action_id=28887&item_id=1443204769634&item_type=file&auth_token=";

  itemId = 240062903338;
  userId = 29490661237;

  redirectUrl =
    "https://app.box.com/index.php?rm=box_openbox_redirect_to_box&service_action_id=28887&item_id=240062903338&item_type=folder&auth_token=";

  console.log("**************STATE_STATE*********************  ", state);
  console.log("CODE = ", code);
  console.log("FILE_ID = ", itemId);
  console.log("USER_ID = ", userId);
  console.log("AUTH_CODE = ", authCode);
  console.log("REDIRECT_URL = ", redirectUrl);
  console.log("**************STATE_STATE*********************");

  const fetchUserData = async (userId, itemId, itemType) => {
    let baseUrl = "https://test7.jeeni.in";
    const url = `${BASE_URL}/box/item/getIntegratedItemDetails`;
    console.log("*******************URL*********************");
    console.log(url);
    console.log(
      "*******************URL*********************",
      userId,
      itemId,
      itemType
    );

    try {
      const data = {
        itemId: itemId,
        itemType: itemType,
        userId: userId,
      };

      const response = await fetch(
        `${baseUrl}/box/item/getIntegratedItemDetail`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );
      // const response = await fetch(url);

      if (response.ok) {
        console.log("*******************RESPONSE*********************");
        const jsonData = await response.json();
        console.log(jsonData);
        console.log(jsonData.status);
        if (jsonData.status) {
          // setData(jsonData.data.itemDetails);
          const { userEmail, jwtToken, refreshToken, userRoles } = {
            ...jsonData.data.userResponse,
          };

          const { itemDetails } = { ...jsonData.data };

          console.log("itemDetails===============", itemDetails);

          console.log("===============", jsonData.data.userResponse);
          dispatch({
            type: "auth/login",
            payload: {
              userEmail,
              jwtToken,
              refreshToken,
              userRoles,
              itemDetails,
            },
          });
          setScreen({ screen: SHOW_DATA, data: jsonData.data.itemDetails });
        } else {
          setScreen({ screen: SHOW_SIGNUP, data: data });
        }
      } else {
        setScreen({ screen: SHOW_ERROR, data: null });
      }

      console.log("*******************RESPONSE*********************");
    } catch (error) {
      setScreen({ screen: SHOW_ERROR, data: error });
      console.log("*******************ERROR*********************");
      console.log(error);
      console.log("*******************ERROR*********************");
    }
  };

  const submitAccessTokenAndRefreshToken = async (
    boxAccessToken,
    boxRefreshToken
  ) => {
    const data = {
      accessToken: boxAccessToken,
      refreshToken: boxRefreshToken,
    };

    try {
      const response = await fetch(`${BASE_URL}/box/user/submitToken`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      console.log("RESPONSE");
      console.log(response);
      if (response.ok) {
        const jsonData = await response.json();
        const { userEmail, jwtToken, refreshToken, userRoles } = {
          ...jsonData.data.userResponse,
        };
        const { itemDetails } = { ...jsonData.data.itemDetails };

        console.log("===============", jsonData.data.userResponse);
        dispatch({
          type: "auth/login",
          payload: {
            userEmail,
            jwtToken,
            refreshToken,
            userRoles,
            boxAccessToken,
            boxRefreshToken,
            itemDetails,
          },
        });

        const params = state.split(",");
        fetchUserData(params[0], params[1], params[2]);
        // fetchUserData
      } else {
        dispatch({
          type: "auth/error",
          payload: "Something Went Wrong",
        });
      }
    } catch (error) {
      setScreen({ screen: SHOW_ERROR, data: error });
      dispatch({
        type: "auth/error",
        payload: "Something Went Wrong",
      });
    }
  };

  async function exchangeCodeForToken(code) {
    try {
      const response = await fetch("https://api.box.com/oauth2/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `grant_type=authorization_code&code=${code}&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&redirect_uri=${REDIRECT_URL}`,
      });

      const data = await response.json();
      if (response.ok) {
        const boxAccessToken = data.access_token;
        const boxRefreshToken = data.refresh_token;

        await submitAccessTokenAndRefreshToken(boxAccessToken, boxRefreshToken);
      } else {
        setScreen({
          screen: SHOW_ERROR,
          data: "Something Went Wrong Please try again",
        });
        dispatch({
          type: "auth/error",
          payload: "Something Went Wrong",
        });
      }
    } catch (error) {
      setScreen({ screen: SHOW_ERROR, data: error });
      dispatch({
        type: "auth/error",
        payload: "Something Went Wrong",
      });
    }
  }

  useEffect(() => {
    // if (!isSignupRequired) {
    console.log("*******************useEffect*********************");
    if (code !== null && state !== null) {
      exchangeCodeForToken(code);
    } else if (userId !== null && itemId !== null && redirectUrl !== null) {
      const redirectUrlQueryParams = new URLSearchParams(redirectUrl);
      const itemType = redirectUrlQueryParams.get("item_type");
      fetchUserData(userId, itemId, itemType);
    } else {
      setScreen({ screen: SHOW_ERROR, data: "Something Went Wrong" });
      console.log("*******************useEffect_ELSE*********************");
    }
  }, []);

  // return <Error />;

  if (screen.screen === SHOW_DATA) {
    if (screen.data.type === "folder") {
      return <FolderAuditorDashboard itemdata={screen.data} />;
    }

    if (screen.data.type === "file") {
      return <AuditorDashboard reduxdata={screen.data} />;
    }

    return <Error />;
  }

  if (screen.screen === SHOW_LOADING) {
    return <Loader />;
  }
  const redirectUrlQueryParams = new URLSearchParams(redirectUrl);
  const itemType = redirectUrlQueryParams.get("item_type");
  if (screen.screen === SHOW_SIGNUP) {
    return <SignUp userId={userId} itemId={itemId} itemType={itemType} />;
  }

  return <Error />;

  // return (
  //   <>
  //     {!isSignupRequired ? (
  //       <Loader />
  //     ) : (
  //       <SignUp userId={userId} itemId={itemId} itemType={"floder"} />
  //     )}
  //   </>
  // );
}

export default Dashboard;
