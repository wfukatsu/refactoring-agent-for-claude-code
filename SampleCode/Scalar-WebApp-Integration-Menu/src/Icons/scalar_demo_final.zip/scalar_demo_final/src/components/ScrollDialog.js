import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { getAuditSetList, addAuditSet } from "./ExternalServices";
import { Alert } from "@mui/material";
import { useSelector } from "react-redux";
import SuccessPopUp from "./SuccessPopUp";
import ClearIcon from '@mui/icons-material/Clear';


export default function ScrollDialog(props) {
  const [open, setOpen] = React.useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = React.useState(false);
  const [scroll, setScroll] = React.useState("paper");
  const [auditlist, setAuditList] = React.useState([]);
  const [selectedId, setSelectedId] = React.useState(0);
  const { user } = useSelector((store) => store.auth);

  const handleClickOpen = (scrollType) => () => {
    setOpen(true);
    setScroll("paper");
  };

  const handleClose = () => {
    setSelectedId("");
    setOpen(false);
  };

  async function handleAdd() {
    const response = await addAuditSet(
      user.jwtToken,
      selectedId,
      props.reduxdata.id,
      props.reduxdata.name,
      props.reduxdata.type,
      props.reduxdata.createdAt
    );
    if (response.ok) {
      const data = await response.json();
      setOpen(false);
      console.log("", data.message);
      setShowSuccessPopup(true)
      //alert(`${data.message}`);
    } else {
      const data = await response.json();
      console.log("", data.message);
      setOpen(false);
      alert(`${data.message}`);
    }

  }

  async function check() {
    const response = await getAuditSetList(user.jwtToken);
    if (response.ok) {
      const data = await response.json();
      console.log("AuditData", data);
      setAuditList(data.data);
    } else {
      console.log("Error fetching VersionHistory data", response);
    }
  }

  const descriptionElementRef = React.useRef(null);
  React.useEffect(() => {
    check();

    if (open) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, []);




  return (
    <React.Fragment>
      <button
        id="btn1"
        onClick={handleClickOpen("paper")}
        style={{
          width: "191px",
          height: "45px",
          borderRadius: "100px",
          padding: "10px, 25px, 10px, 25px",
          color: "white",
        }}
        onMouseEnter={(e) => (e.target.style.backgroundColor = "#0061D0")}
        onMouseLeave={(e) => (e.target.style.backgroundColor = "#0061D5")}
      >
        Add to Audit Set
      </button>


      {open &&
        <Dialog
          open={open}
          onClose={handleClose}
          scroll={scroll}
          aria-labelledby="scroll-dialog-title"
          aria-describedby="scroll-dialog-description"
          maxWidth="800px"
          height="800px"
        >
          <DialogTitle id="scroll-dialog-title">
            <div style={{ display: "flex", flexDirection: "row", justifyContent: "space-between" }}>
              <h2>Audit Sets</h2>
              <ClearIcon onClick={handleClose}></ClearIcon>
            </div>

          </DialogTitle>

          <DialogContent dividers={scroll === "paper"}>
            <DialogContentText
              id="scroll-dialog-description"
              ref={descriptionElementRef}
              tabIndex={-1}
            >
              <div
                style={{
                  width: "700px",
                  tableLayout: "fixed",
                  overflowX: "hidden",
                }}
              >
                <table border="1" style={{ width: "100%", tableLayout: "fixed" }}>
                  <thead>
                    <tr style={{ height: "59px" }}>
                      <th
                        style={{
                          color: "white",
                          backgroundColor: "#0061D0",
                          paddingLeft: "20px",
                          textAlign: "left",
                          width: "30%",
                          borderTopLeftRadius: "20px"
                        }}
                      >
                        SELECT
                      </th>
                      <th
                        style={{
                          color: "white",
                          backgroundColor: "#0061D0",
                          paddingLeft: "25px",
                          textAlign: "left",
                          width: "70%",
                          borderTopRightRadius: "20px"
                        }}
                      >
                        Name
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Iterate over the auditlist data and generate table rows dynamically */}
                    {auditlist &&
                      auditlist.map((item, index) => (
                        <tr key={index} style={{ height: "59px" }}>
                          <td
                            style={{
                              color: "black",
                              textAlign: "left",
                              paddingLeft: "25px",
                              width: "30%",
                              display: "table-cell",
                              verticalAlign: "middle",
                            }}
                          >
                            <input
                              type="radio"
                              id={`input${index}`}
                              name="option"
                              value={item.auditSetId}
                              onClick={() => {
                                setSelectedId(item.auditSetId);
                              }}
                            />
                          </td>
                          <td
                            style={{
                              color: "black",
                              textAlign: "left",
                              paddingLeft: "25px",
                              width: "70%",
                              display: "table-cell",
                              verticalAlign: "middle",
                              overflowWrap: "break-word",
                            }}
                          >
                            {item.auditSetName ? item.auditSetName : "NA"}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </DialogContentText>
          </DialogContent>

          <DialogActions>
            {/* <Button onClick={handleClose}>Cancel</Button> */}
            <Button onClick={handleAdd}
              disabled={!true || !selectedId}
              style={{ color: "white", backgroundColor: (!selectedId) ? 'rgba(0,97,213,0.6)' : '#0061D5' }}
            >Add</Button>
          </DialogActions>
        </Dialog>
      }



      {showSuccessPopup && (
        <SuccessPopUp
          iconColor="primary"
          iconSize={50}
          title="Audit Set Added Successfully"
          open={true}
          handleClose={() => setShowSuccessPopup(false)}


        />
      )}



    </React.Fragment>
  );
}












