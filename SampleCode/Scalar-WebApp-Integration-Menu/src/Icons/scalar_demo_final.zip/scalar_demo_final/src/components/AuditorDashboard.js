import React, { useEffect, useState } from "react";
import Header from "./Header";
import "./AuditorDashboard.css";
import FileDetails from "./FileDetails";
import { getFileCopy, getVersionHistory } from "./ExternalServices";
import ScrollDialog from "./ScrollDialog";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { styled, useTheme } from "@mui/material/styles";
import Paper from "@mui/material/Paper";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    fontSize: 20,
    backgroundColor: "#0061D5",
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));
const columns = [
  { id: "version", label: "Version", minWidth: 150, align: "center" },
  { id: "updatedat", label: "Updated At", minWidth: 150, align: "center" },
  { id: "hash", label: " Hash (SHA1)", minWidth: 150, align: "center" },
];

const columns2 = [
  { id: "Filename", label: "Filename", minWidth: 150, align: "center" },
  { id: "Created", label: "	Created at", minWidth: 150, align: "center" },
  { id: "path", label: " Path", minWidth: 150, align: "center" },
];

function AuditorDashboard() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const navigate = useNavigate();
  const { user } = useSelector((store) => store.auth);

  const { itemDetails } = { ...user };
  const { id, sha1 } = { ...itemDetails };
  console.log("TOKEN :: ", user);
  console.log("itemDetails@@@@@@ :: ", itemDetails);

  const [isVersionHistorySelected, setIsVersionHistorySelected] =
    useState(true);

  const [dataList, setDataList] = useState([]);
  const [fileDetailsBox, setfileDetailsBox] = useState(true);
  const [versionHistoryData, setVersionHistoryData] = useState([]);
  const [fileCopyData, setFileCopyData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);

  async function check() {
    const response = await getVersionHistory(id, user.jwtToken);
    if (response.ok) {
      const data = await response.json();
      setVersionHistoryData(data.data);
      setDataList(data.data);
      console.log("done---", data);
    } else {
      console.log("Error fetching VersionHistory data", response);
    }
    const response1 = await getFileCopy(id, sha1, user.jwtToken);
    if (response1.ok) {
      const data1 = await response1.json();
      setFileCopyData(data1.data);
      setDataList(data1.data);
      console.log("done1----", data1);
    } else {
      console.log("Error fetching VersionHistory data", response);
    }
  }

  useEffect(() => {
    check();
  }, []);

  //////////// pagination///////////
  const itemsPerPage = 8;

  const formatDate = (mydate) => {
    const dateString = "" + mydate;
    const year = dateString.slice(0, 4);
    const month = dateString.slice(4, 6);
    const day = dateString.slice(6, 8);
    const formattedDate = `${day}/${month}/${year}`;
    return formattedDate;
  };

  return (
    <div className="flex flex-col">
      <Header />
      <header className="flex flex-col flex-grow">
        <div className="bg-white text-xl flex justify-start gap-5 p-3 ml-4">
          <h3>
            <b>File Name : {itemDetails.name}</b>
          </h3>
          <h6>File path : {itemDetails.path?itemDetails.path:"NA"}</h6>
        </div>

        <div className="bg-white flex justify-between ml-3">
        <div
            className="bg-white justify-start gap-2"
            style={{
              display: "flex",
              flexDirection: "row",
              paddingLeft: "12px",
            }}
          >
            <h3 style={{padding:"4px"}}>
              <b>Tampering Status :</b>{" "}
            </h3>
            <div className="text-blue-600 text px-5 p-1  bg-green-100 border  justify-items-center justify-center rounded-xl text-center">
              <b> {itemDetails.tamperedStatus} </b>
            </div>
          </div>

          <div
            className="bg-white justify-start gap-2"
            style={{ display: "flex", flexDirection: "row" }}
          >
            <ScrollDialog reduxdata={itemDetails}></ScrollDialog>
            <button
              id="btn2"
              style={{
                width: "212px",
                height: "45px",
                borderRadius: "100px",
                padding: "10px, 10px, 10px, 10px",
                border: "1px solid #0061D5",
              }}
              onMouseEnter={(e) =>
                (e.target.style.backgroundColor = "lightgray")
              }
              onMouseLeave={(e) => (e.target.style.backgroundColor = "white")}
              onClick={() => navigate("/event-history")}
            >
              {" "}
              View Event History
            </button>
            {/* <div style={{ width: "25px" }}></div> */}
          </div>
        </div>

        {/*table selection Buttons */}
        <div className="bg-white gap-x-8 px-3 py-1 m-3">
          <div
            style={{
              backgroundColor: "#D9D9D9",
              width: "555px",
              display: "flex",
              flexDirection: "row",
            }}
          >
            <button
              class={`btn ${isVersionHistorySelected ? "button1" : "default"}`}
              onClick={() => setIsVersionHistorySelected(true)}
              style={{ width: "278px" }}
            >
              {" "}
              Version History{" "}
            </button>
            <button
              class={`btn ${!isVersionHistorySelected ? "button2" : "default"}`}
              onClick={() => setIsVersionHistorySelected(false)}
              style={{ width: "278px" }}
            >
              {" "}
              File Copies{" "}
            </button>
          </div>
        </div>

        <div
          style={{
            backgroundColor: "white",
            marginLeft: "14px",
            display: "flex",
            flexDirection: "row",
            gap: "20px",
            flexWrap: "wrap",
            minHeight: "660px",
          }}
        >
          <div
            style={{
              marginLeft:"5px",
              width: "70%",
              // height: "650px",
              backgroundColor: "rgba(204,223,247,0.12)",
            }}
          >
            {/* {isVersionHistorySelected && (
              <div style={{ width: "100%", height: "610px" }}>
                <table className="table-container">
                  <thead class="table-heading">
                    <tr>
                      <th style={{ width: "20%" }}>Version</th>
                      <th style={{ width: "20%" }}>Updated at</th>
                      <th style={{ width: "60%" }}>Hash (SHA1)</th>
                    </tr>
                  </thead>
                  <tbody className="table-body">
                    {versionHistoryData &&
                      versionHistoryData.map((item, index) => (
                        <tr key={index} className="table-row">
                          <td style={{ width: "20%" }}>
                            {item.itemVersionNumber}
                          </td>
                          <td style={{ width: "20%" }}>
                            {formatDate(item.modified_at)}
                          </td>
                          <td style={{ width: "60%" }}>{item.sha1Hash}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )} */}
            {isVersionHistorySelected && (
              <Paper
                style={{
                  width: "100%",
                  overflow: "hidden",
                  borderRadius: "25px",

                  backgroundColor: "#F9FBFE",
                }}
              >
                {versionHistoryData.length === 0 ? (
                  <>
                  
                    <TableContainer
                      style={{
                        width: "100%",
                        overflow: "hidden",
                      }}
                    >
                      <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                          <TableRow>
                            {columns2.map((column) => (
                              <StyledTableCell
                                key={column.id}
                                align={"center"}
                                style={{ minWidth: column.minWidth }}
                              >
                                {column.label}
                              </StyledTableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          <TableRow>
                            <TableCell colSpan={columns2.length}>
                              <div
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                  minHeight: "500px", // Adjust height as needed
                                }}
                              >
                                <p className="text-xl font-bold">
                                  No Files Copies Are Available
                                </p>
                              </div>
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </>
                ) : (
                  <>
                    <TableContainer style={{ maxHeight: 440 }}>
                      <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                          <TableRow>
                            {columns.map((column) => (
                              <StyledTableCell
                                key={column.id}
                                align={"center"}
                                style={{ minWidth: column.minWidth }}
                              >
                                {column.label}
                              </StyledTableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {versionHistoryData &&
                            versionHistoryData
                              .slice(
                                page * rowsPerPage,
                                page * rowsPerPage + rowsPerPage
                              )
                              .map((item, index) => (
                                <TableRow key={index}>
                                  <TableCell align="center">
                                    {item.itemVersionNumber}
                                  </TableCell>
                                  <TableCell align="center">
                                    {formatDate(item.modified_at)}
                                  </TableCell>
                                  <TableCell align="center">
                                    {item.sha1Hash}
                                  </TableCell>
                                </TableRow>
                              ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    <TablePagination
                      rowsPerPageOptions={[5, 10, 25]}
                      component="div"
                      count={versionHistoryData.length}
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                  </>
                )}
              </Paper>
            )}

            {!isVersionHistorySelected && (
              <Paper
                style={{
                  width: "100%",
                  overflow: "hidden",
                  borderRadius: "25px",
                  backgroundColor: "#F9FBFE",
                }}
              >
                {fileCopyData.length === 0 ? (
                  <>
                    <TableContainer
                      style={{
                        width: "100%",
                        overflow: "hidden",
                      }}
                    >
                      <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                          <TableRow>
                            {columns2.map((column) => (
                              <StyledTableCell
                                key={column.id}
                                align={"center"}
                                style={{ minWidth: column.minWidth }}
                              >
                                {column.label}
                              </StyledTableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          <TableRow>
                            <TableCell colSpan={columns2.length}>
                              <div
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                  minHeight: "500px", // Adjust height as needed
                                }}
                              >
                                <p className="text-xl font-bold">
                                  No Files Copies Are Available
                                </p>
                              </div>
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </>
                ) : (
                  <>
                    <TableContainer
                      style={{
                        width: "100%",
                        overflow: "hidden",
                      }}
                      // style={{ maxHeight: 440 }}
                    >
                      <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                          <TableRow>
                            {columns2.map((column) => (
                              <StyledTableCell
                                key={column.id}
                                align={"center"}
                                style={{ minWidth: column.minWidth }}
                              >
                                {column.label}
                              </StyledTableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fileCopyData &&
                            fileCopyData
                              .slice(
                                page * rowsPerPage,
                                page * rowsPerPage + rowsPerPage
                              )
                              .map((item, index) => (
                                <TableRow key={index}>
                                  <TableCell align="center">
                                    {item.itemName}
                                  </TableCell>
                                  <TableCell align="center">
                                    {formatDate(item.createdAt)}
                                  </TableCell>
                                  <TableCell align="center">
                                    {item.path}
                                  </TableCell>
                                </TableRow>
                              ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    <TablePagination
                      rowsPerPageOptions={[5, 10, 25]}
                      component="div"
                      count={fileCopyData.length}
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                  </>
                )}
              </Paper>
            )}
          </div>
          <div className="w-[27%]">
            <FileDetails obj={itemDetails} isfiledetails={true} />
          </div>
        </div>
      </header>
    </div>
  );
}

export default AuditorDashboard;
