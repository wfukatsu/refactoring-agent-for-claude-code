import React from "react";
import { ReactComponent as CloseSVG } from "../svgicons/close_FILL1_wght300_GRAD0_opsz24 (1) 1.svg";

const ClearButton = ({ onClick }) => {
  const handleClick = () => {
    if (onClick) {
      onClick(); // Invoke the provided callback function
    }
  };

  const containerStyle = {
    width: "80px",
    height: "30px",
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
  };

  return (
    <div style={containerStyle} onClick={handleClick}>
      <CloseSVG />
      <button
        style={{
          width: 80,
          cursor: "pointer",
          border: "none",
          backgroundColor: "white",
        }}
      >
        Clear All
      </button>
    </div>
  );
};

export default ClearButton;
