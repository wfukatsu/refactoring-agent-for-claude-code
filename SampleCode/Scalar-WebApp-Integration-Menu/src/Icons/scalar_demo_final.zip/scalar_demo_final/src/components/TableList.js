import React, { useState } from "react";
import "../css/tablestyle.css";


import { styled, useTheme } from "@mui/material/styles";
import Paper from "@mui/material/Paper";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    fontSize: 20,
    backgroundColor: "#0061D5",
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const columns2 = [
  { id: "itemName", label: "Item Name", minWidth: 150, align: "center" },
  { id: "EventType", label: "	Event Type", minWidth: 150, align: "center" },
  { id: "performedBy", label: " Performed By", minWidth: 150, align: "center" },
  { id: "eventOccured", label: " Event Occured at", minWidth: 150, align: "center" },
];

const TableList = ({ dataList }) => {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

 


  return (
    <div className="main-container">
                  
              <Paper
                style={{
                  width: "100%",
                  overflow: "hidden",
                  borderRadius: "25px",

                  backgroundColor: "#F9FBFE",
                }}
              >
                {dataList &&dataList.length === 0 ? (
                  <>
                  
                    <TableContainer
                      style={{
                        width: "100%",
                        overflow: "hidden",
                      }}
                    >
                      <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                          <TableRow>
                            {columns2.map((column) => (
                              <StyledTableCell
                                key={column.id}
                                align={"center"}
                                style={{ minWidth: column.minWidth }}
                              >
                                {column.label}
                              </StyledTableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          <TableRow>
                            <TableCell colSpan={columns2.length}>
                              <div
                                style={{
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                  minHeight: "500px", // Adjust height as needed
                                }}
                              >
                                <p className="text-xl font-bold">
                                No file event history is available
                                </p>
                              </div>
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </>
                ) : (
                  <>
                    <TableContainer style={{ maxHeight: 440 }}>
                      <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                          <TableRow>
                            {columns2.map((column) => (
                              <StyledTableCell
                                key={column.id}
                                align={"center"}
                                style={{ minWidth: column.minWidth }}
                              >
                                {column.label}
                              </StyledTableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {dataList &&
                            dataList
                              .slice(
                                page * rowsPerPage,
                                page * rowsPerPage + rowsPerPage
                              )
                              .map((item, index) => (
                                <TableRow key={index}>
                                  <TableCell align="center">
                                    {item.itemName}
                                  </TableCell>
                                  <TableCell align="center">
                                  {item.eventType}
                                  </TableCell>
                                  <TableCell align="center">
                                  {item.eventCreatedUserName}
                                  </TableCell>
                                  <TableCell align="center">
                                  {item.eventCreatedAt}
                                  </TableCell>
                                </TableRow>
                              ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    <TablePagination
                      rowsPerPageOptions={[5, 10, 25]}
                      component="div"
                      count={dataList.length}
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                  </>
                )}
              </Paper>
            
    </div>
  );
};

export default TableList;
