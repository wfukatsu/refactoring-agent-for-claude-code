import { useDispatch, useSelector } from "react-redux";
import "../css/dropdown.css";
import { useEffect } from "react";

export default function DropDown({ itemId }) {
  const { user } = useSelector((store) => store.auth);
  const { selectedAuditSet, auditSetList } = useSelector(
    (store) => store.folder
  );

  console.log("DropDown", selectedAuditSet);
  const dispatch = useDispatch();

  useEffect(() => {
    async function fetchAuditSet() {
      let baseUrl = "http://test7.jeeni.in";
      if (auditSetList.length === 0) {
        const headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append(
          "Authorization",
          `Bearer ${encodeURIComponent(user.jwtToken)}`
        );

        const url = `${baseUrl}/box/auditSet/getMyAuditSetList`;
        const response = await fetch(url, {
          method: "GET",
          headers: headers,
        });

        if (response.ok) {
          const jsonData = await response.json();

          let auditSetList = [...jsonData.data];
          dispatch({
            type: "auditFolder/updateAuditSet",
            payload: {
              auditSetList,
            },
          });
        }
      }
    }

    fetchAuditSet();
  }, [auditSetList, dispatch]);

  async function fetchAuditSetDeniList(auditSet) {
    let baseUrl = "http://test7.jeeni.in";
    if (auditSet === "null") {
      let deniedList = [];
      dispatch({
        type: "auditFolder/updateSelectedAuditSet",
        payload: {
          auditSet,
          deniedList,
        },
      });
      return;
    }

    const headers = new Headers();
    headers.append("Content-Type", "application/json");
    headers.append(
      "Authorization",
      `Bearer ${encodeURIComponent(user.jwtToken)}`
    );

    const url = `${baseUrl}/box/auditSetItem/getItemDenyListFromAuditSet/${encodeURIComponent(
      auditSet
    )}/${encodeURIComponent(240062903338)}`;
    const response = await fetch(url, {
      method: "GET",
      headers: headers,
    });

    if (response.ok) {
      const jsonData = await response.json();
      console.log("RESPONSE", jsonData.data);
      let deniedList = [...jsonData.data];
      dispatch({
        type: "auditFolder/updateSelectedAuditSet",
        payload: {
          auditSet,
          deniedList,
        },
      });
    }
  }

  return (
    <div className="custom-lable-layout-container-five">
      <select
        className="dropdown-css"
        style={{ paddingLeft: 10 }}
        onChange={async (event) => {
          console.log(event.target.value);
          const auditSet = event.target.value;
          await fetchAuditSetDeniList(auditSet);
        }}
        value={selectedAuditSet}
      >
        <option value="null">Select</option>
        {[...auditSetList].map((auditSet, index) => (
          <option
            style={{ fontSize: "16px" }}
            className="dropdown-css-options"
            key={index}
            value={auditSet.auditSetId} // Set userId as the value
          >
            {auditSet.auditSetName}
          </option>
        ))}
      </select>
    </div>
  );
}
