import "../css/filehistory.css";
import "../css/customLayout.css";
import CustomLayout from "./CusotmLayout.js";

import {
  FetchEventHistory,
  FetchItemCollbrater,
  FetchEventType,
  FetchEventHistorybyUser,
  FetchEventHistorybyEvent,
  FetchEventHistorybyUserandEvent,
} from "../data/NetworkLayer.js";

import dayjs from "dayjs";

import React, { useState, useEffect } from "react";
import ClearButton from "./ClearButton.js";
import TableList from "./TableList.js";
import { useSelector } from "react-redux";
import Header from "./Header.js";

const ViewEventHistory = () => {
  const [eventHistoryData, setEventHistoryData] = useState([]);
  const [collbraterList, setItemColbratter] = useState([]);
  const [eventTypeList, setEventTypeList] = useState([]);

  const { user } = useSelector((store) => store.auth);

  const { itemDetails } = { ...user };
  const { id, sha1, path, type, name } = { ...itemDetails };
  console.log("id :: ", id, " PATH:: ", "type :: ", type);
  //   {
  //     "id": 1395086776443,
  //     "name": "Input-response.txt",
  //     "type": "file",
  //     "description": "",
  //     "createdAt": "20231221103645",
  //     "modifiedAt": "20231221103645",
  //     "size": 3484,
  //     "sha1": "9e51f29941f4c23e35c926bcbbec375466ed923a",
  //     "ownedBy": {
  //         "type": "USER",
  //         "id": "29490661237",
  //         "name": "Pooja Patil",
  //         "login": "poojap@kanzencs.com"
  //     },
  //     "modifiedBy": {
  //         "type": "USER",
  //         "id": "29490661237",
  //         "name": "Pooja Patil",
  //         "login": "poojap@kanzencs.com"
  //     },
  //     "tamperedStatus": "Not_Monitored",
  //     "path": null
  // }

  const fetchProjects = async (fileItemId, startDateString, endDateString) => {
    try {
      console.log(
        "1",
        fileItemId,
        "start dat",
        startDateString,
        "end date \n",
        endDateString
      ); //startDateString,endDateString
      const response = await FetchEventHistory(
        fileItemId,
        startDateString,
        endDateString,
        user.jwtToken
      );

      if (response.ok) {
        console.log("4");
        const data = await response.json();
        setEventHistoryData(data.data);
      } else if (response.status === 401) {
        console.log("Error fetching data", response.status);
      }
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
  };

  const fetchEvents = async () => {
    //startDateString, endDateString
    try {
      console.log("1"); //startDateString,endDateString
      const response = await FetchEventType(user.jwtToken);

      if (response.ok) {
        console.log("4");
        const data = await response.json();
        setEventTypeList(data.data);
      } else if (response.status === 401) {
        console.log("Error fetching data", response.status);
      }
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
  };

  const fetchColbratterMethod = async (fileItemId, fileTypee) => {
    //startDateString, endDateString
    try {
      console.log("1", fileItemId, "file type", fileTypee); //startDateString,endDateString
      const response = await FetchItemCollbrater(
        fileItemId,
        fileTypee,
        user.jwtToken
      );

      if (response.ok) {
        console.log("4");
        const data = await response.json();
        setItemColbratter(data.data);
      } else if (response.status === 401) {
        console.log("Error fetching data", response.status);
      }
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
  };

  /////////////////////////////////////////////////////////////////////////////////////////////////

  const fetchDataByUser = async (
    fileItemId,
    selectedUserr,
    startDateString,
    endDateString
  ) => {
    try {
      console.log(
        "1 user ",
        selectedUserr,
        "start dat",
        startDateString,
        "end date \n",
        endDateString,
        "file id",
        fileItemId,
        "userid ",
        selectedUserr
      );
      const response = await FetchEventHistorybyUser(
        formatDateMethod(startDate),
        formatDateMethod(endDate),
        selectedUserr,
        fileItemId,
        user.jwtToken
      );

      if (response.ok) {
        console.log("4");
        const data = await response.json();
        setEventHistoryData(data.data);
      } else if (response.status === 401) {
        console.log("Error fetching data", response.status);
      }
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
  };


  const fetchDataByEvent = async (
    fileItemId,
    eventTypeStr,
    startDateString,
    endDateString
  ) => {
    try {
      console.log(
        "start dat",
        startDateString,
        "end date \n",
        endDateString,
        "event id",
        eventTypeStr,
        "file id",
        fileItemId,
      );
      const response = await FetchEventHistorybyEvent(
        startDateString,
        endDateString,
        eventTypeStr,
        fileItemId,
        user.jwtToken
      );

      if (response.ok) {
        console.log("4");
        const data = await response.json();
        setEventHistoryData(data.data);
      } else if (response.status === 401) {
        console.log("Error fetching data", response.status);
      }
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
  };

  const fetchDataByUserandEvent = async (
    fileItemId,
    selectedUserr,
    eventTypeStr,
    startDateString,
    endDateString
  ) => {
    try {
      console.log(
        "1 user ",
        selectedUserr,
        "start dat",
        startDateString,
        "end date \n",
        endDateString,
        "file id",
        fileItemId,
        "userid ",
        selectedUserr
      );
      const response = await FetchEventHistorybyUserandEvent(
        startDate,
        endDate,
        eventTypeStr,
        selectedUserr,
        fileItemId,
        user.jwtToken
      );

      if (response.ok) {
        console.log("4");
        const data = await response.json();
        setEventHistoryData(data.data);
      } else if (response.status === 401) {
        console.log("Error fetching data", response.status);
      }
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
  };

  const today = dayjs();
  const yesterday = dayjs().subtract(15, "day");

  const [startDate, setStartDate] = React.useState(yesterday);
  const [endDate, setEndDate] = React.useState(today);

  const [selectedUserName, setSelectedUserName] = useState("");
  const [selectedEventName, setSelectedEventName] = useState("");

  const handleUserNameChange = (newUserName) => {
    setSelectedUserName(newUserName);
  };

  const handleEventNameChange = (newEventName) => {
    setSelectedEventName(newEventName);
  };

  const clearFields = () => {
    setStartDate(null);
    setEndDate(null);
    setSelectedUserName("");
    setSelectedEventName("");
    setEventHistoryData([]);
  };

  const formatDateMethod = (Datee) => {
    const formattedDate = new Intl.DateTimeFormat(undefined, {
      year: "numeric",
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      fractionalSecondDigits: 3,
    }).format(Datee);

    const formattedDateWithColon = Datee.format("YYYY/MM/DD HH:mm:ss:SSS");

    return formattedDateWithColon;
  };

  const viewAllHandle = () => {
    if (startDate != null && endDate != null) {
      const formattedDateResultOne = formatDateMethod(startDate);
      const formattedDateResultTwo = formatDateMethod(endDate);

      console.log("start date =", formattedDateResultOne);
      console.log("end date =", formattedDateResultTwo);
    }

    if (
      startDate !== null &&
      endDate !== null &&
      selectedUserName === "" &&
      selectedEventName === ""
    ) {
      console.log(
        "first api call date only ",
        formatDateMethod(startDate),
        "end date",
        formatDateMethod(endDate),
        "user",
        selectedUserName,
        "event",
        selectedEventName
      );

      fetchProjects(id, formatDateMethod(startDate), formatDateMethod(endDate));
    } else if (
      startDate !== null &&
      endDate !== null &&
      selectedUserName !== "" &&
      selectedEventName === ""
    ) {
      console.log(
        "second api call ",
        formatDateMethod(startDate),
        "end date",
        formatDateMethod(endDate),
        "user",
        selectedUserName,
        "event",
        selectedEventName
      );

      fetchDataByUser(
        id,
        selectedUserName,
        formatDateMethod(startDate),
        formatDateMethod(endDate)
      );
    } else if (
      startDate !== null &&
      endDate !== null &&
      selectedUserName === "" &&
      selectedEventName !== ""
    ) {
      console.log(
        "third api call",
        formatDateMethod(startDate),
        "end date",
        formatDateMethod(endDate),
        "user",
        selectedUserName,
        "event",
        selectedEventName
      );

      fetchDataByEvent(
        id,
        selectedEventName,
        formatDateMethod(startDate),
        formatDateMethod(endDate)
      );
    } else if (
      startDate !== null &&
      endDate !== null &&
      selectedUserName !== "" &&
      selectedEventName !== ""
    ) {
      console.log(
        "fourth api call",
        formatDateMethod(startDate),
        "end date",
        formatDateMethod(endDate),
        "user",
        selectedUserName,
        "event",
        selectedEventName
      );

      fetchDataByUserandEvent(
        id,
        selectedUserName,
        selectedEventName,
        formatDateMethod(startDate),
        formatDateMethod(endDate)
      );
    }
  };

  useEffect(() => {
    console.log("File ID in useEffect:", id);
    fetchProjects(id, formatDateMethod(startDate), formatDateMethod(endDate));
    fetchEvents();
    fetchColbratterMethod(id, type);
  }, []);

  return (
    <div>
      <Header/>
      <div className="file-information-container">
        <div className="folder-name-text">Folder name: {name}</div>
        <div className="file-path-name-text">File Path: {path}</div>
      </div>
      <div className="white-line"></div>
      <div className="file-information-container">
        <div className="filter-text">Filter: </div>

        <div style={{ height: "20px", width: "20px" }}></div>

        <div className="custom-lable-layout-container-one">
          <CustomLayout
            typeContainer={"DatePicker"}
            value={startDate}
            setValue={setStartDate}
          />
        </div>

        <div style={{ height: "20px", width: "20px" }}></div>

        <div className="custom-lable-layout-container-two">
          <CustomLayout
            typeContainer={"DatePicker"}
            value={endDate}
            setValue={setEndDate}
          />
        </div>

        <div style={{ height: "20px", width: "20px" }}></div>

        <div className="custom-lable-layout-container-three">
          <CustomLayout
            firstList={true}
            dropdownList={collbraterList}
            selectedOption={selectedUserName}
            onDropdownChange={handleUserNameChange}
          />
        </div>

        <div style={{ height: "20px", width: "20px" }}></div>
        <div className="custom-lable-layout-container-four">
          <CustomLayout
            firstList={false}
            dropdownListTwo={eventTypeList}
            selectedOption={selectedEventName}
            onDropdownChange={handleEventNameChange}
          />
        </div>

        <div style={{ height: "20px", width: "20px" }}></div>

        <button
          style={{
            width: 80,
            cursor: "pointer",
            border: "none",
            backgroundColor: "white",
          }}
          onClick={viewAllHandle}
        >
          View All
        </button>

        <div style={{ height: "20px", width: "20px" }}></div>
        <ClearButton onClick={clearFields} />
      </div>

      <TableList dataList={eventHistoryData} />
    </div>
  );
};

export default ViewEventHistory;
