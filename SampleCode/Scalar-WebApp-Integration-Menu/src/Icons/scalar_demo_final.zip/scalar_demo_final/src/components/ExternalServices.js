let baseUrl = "https://test7.jeeni.in";
export const getVersionHistory = async (fileId, token) => {
  const getFileVersion = `${baseUrl}/box/file/getFileVersions?fileId=${fileId}`;
  const response = await fetch(`${getFileVersion}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  });
  console.log("1-2");
  return response;
};

export const getFileCopy = async (fileId, sha1, token) => {
  console.log("1-1");
  const getfilecopies = `${baseUrl}/box/file/getFileCopies?sha1Hash=${sha1}&itemId=${fileId}`;
  const response = await fetch(`${getfilecopies}`, {
    method: "GET",

    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  });
  console.log("1-2");
  return response;
};

export const addAuditSet = async (
  token,
  auditSetId,
  itemId,
  itemName,
  itemType,
  createdAt
) => {
  const addAuditSet_url = `${baseUrl}/box/auditSetItem/addItemToAuditSet/${auditSetId}`;
  const requestData = {
    itemId: itemId,
    itemType: itemType,
    itemName: itemName,
    createdAt: createdAt,
  };
  const response = await fetch(`${addAuditSet_url}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(requestData),
  });
  return response;
};

export const getAuditSetList = async (token) => {
  const getAuditList = `${baseUrl}/box/auditSet/getMyAuditSetList`;
  const response = await fetch(`${getAuditList}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  });
  return response;
};

export const getFileCopy2 = async (token) => {
  const getFileProperty = `${baseUrl}/box/file/getFileDetails?itemId=1415608897455`;
  const response = await fetch(`${getFileProperty}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  });
  return response;
};
