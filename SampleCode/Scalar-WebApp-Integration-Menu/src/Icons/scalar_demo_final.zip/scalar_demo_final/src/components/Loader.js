import { BeatLoader } from "react-spinners";

function Loader() {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: "100vh",
      }}
    >
      <BeatLoader color="#2834d8" />
    </div>
  );
}

export default Loader;