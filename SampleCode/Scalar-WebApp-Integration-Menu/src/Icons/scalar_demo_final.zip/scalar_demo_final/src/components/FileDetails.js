import React from "react";
import "./AuditorDashboard.css";
//  import { ReactComponent as Icon1 } from "../images/Icon1.svg";
//  import { ReactComponent as Icon2 } from "../images/Icon2.svg";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import InsertDriveFileOutlinedIcon from '@mui/icons-material/InsertDriveFileOutlined';
import Paper from "@mui/material/Paper";

function FileDetails(props) {
  return (
    <div className="bg-[#F9FBFE]">
      <div
        style={{
          width: "100%",
          backgroundColor: "#0061D5",
          fontSize: "20px",
          fontWeight: "700",
          borderTopLeftRadius: "16px",
          borderTopRightRadius: "16px",
          minHeight: "59px",
          color: "white",
          paddingLeft: "22px",
          paddingRight: "10px",
          paddingTop: "12px",
          paddingBottom: "12px",
        }}
      >
        File Properties
      </div>

      {/* <div className="flex w-full px-7 py-2 border border-b-gray-400 gap-5 justify-start items-center">
        <CalendarTodayIcon sx={{ color: "#0061D5" }} />
        <div className="felx flex-col" style={{width:"90%"}}>
          <p className="text-md">Name</p>
          <p className="text-[17px]  font-bold" style={{overflowY: "auto", wordWrap: "break-word"}}>{props.obj.name}</p>
        </div>
      </div> */}
      <div className="flex w-full px-7 py-2 border border-b-gray-400 gap-5 justify-start items-center">
        <InsertDriveFileOutlinedIcon sx={{ color: "#0061D5" }} />
        <div className="felx flex-col">
          <p className="text-md">Owned by</p>
          <p className="text-[17px]  font-bold"> {props.obj.ownedBy?.name}</p>
        </div>
      </div>
      <div className="flex w-full px-7 py-2 border border-b-gray-400 gap-5 justify-start items-center">
        <CalendarTodayIcon sx={{ color: "#0061D5" }} />
        <div className="felx flex-col" style={{width:"90%"}}>
          <p className="text-md"> Created at</p>
          <p className="text-[17px]  font-bold" style={{overflowY: "auto", wordWrap: "break-word"}}> {props.obj.createdAt}</p>
        </div>
      </div>
      <div className="flex w-full px-7 py-2 border border-b-gray-400 gap-5 justify-start items-center">
        <CalendarTodayIcon sx={{ color: "#0061D5" }} />
        <div className="felx flex-col">
          <p className="text-md "> Modified by</p>
          <p className="text-[17px]  font-bold">
            {" "}
            {props.obj.modifiedBy?.name}
          </p>
        </div>
      </div>
      <div className="flex w-full px-7 py-2 border border-b-gray-400 gap-5 justify-start items-center">
        <InsertDriveFileOutlinedIcon sx={{ color: "#0061D5" }} />
        <div className="felx flex-col" style={{width:"90%"}}>
          <p className="text-md"> Modified at</p>
          <p className="text-[17px] font-bold" style={{overflowY: "auto", wordWrap: "break-word"}}> {props.obj.modifiedAt}</p>
        </div>
      </div>

      <div className="flex w-full px-7 py-2 border border-b-gray-400 gap-5 justify-start items-center">
        <CalendarTodayIcon sx={{ color: "#0061D5" }} />
        <div className="felx flex-col">
          <p className="text-md"> Size</p>
          <p className="text-[17px]  font-bold"> {props.obj.size} Mb</p>
        </div>
      </div>

      {props.isfiledetails && (
        <div className="flex w-full px-7 rounded-bl-xl rounded-br-xl py-2 border  border-b-gray-400 gap-5 justify-start items-center" >
          <CalendarTodayIcon sx={{ color: "#0061D5" }} />
          <div className="felx flex-col " style={{width:"90%"}}>
            <p className="text-md"> Sha1 Hash</p>
            <p className="text-[17px]  font-bold" style={{overflowY: "auto", wordWrap: "break-word"}}> {props.obj.sha1}</p>
          </div>
        </div>
      )}



    </div>
  );
}

export default FileDetails;
